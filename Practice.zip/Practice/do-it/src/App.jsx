import './App.css'
import React from 'react';
import Student from './Student.jsx'

function App() {
  return(
    <div>
      <Student></Student>
    </div>
  )
  
}

export default App
