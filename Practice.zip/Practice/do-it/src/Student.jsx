import React from 'react';

const Product = ({ name, description, price, image, relatedProducts }) => {
    return (
        <div className="product">
            <img src={image} alt={name} />
            <h2>{name}</h2>
            <p>{description}</p>
            <p>Price: ${price}</p>
            <h3>Related Products:</h3>
            <ul>
                {relatedProducts.map((relatedProduct, index) => (
                    <li key={index}>{relatedProduct}</li>
                ))}
            </ul>
        </div>
    );
};

export default Product;